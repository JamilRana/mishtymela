import React from "react";
import { cn } from "@/lib/utils";
import { BorderBeam } from "@/components/ui/border-beam";

interface KpiCardProps {
  label: string;
  value: React.ReactNode;
  subtitle?: React.ReactNode;
  icon?: React.ReactNode;
  badge?: React.ReactNode;
  className?: string;
  withBeam?: boolean;
}

export const KpiCard: React.FC<KpiCardProps> = ({
  label,
  value,
  subtitle,
  icon,
  badge,
  className,
  withBeam,
}) => {
  return (
    <div
      className={cn(
        "relative overflow-hidden bg-surface border border-slate-200 rounded-md p-5 flex flex-col justify-between hover:border-slate-300 transition-colors",
        className
      )}
    >
      {withBeam && (
        <BorderBeam size={160} duration={8} colorFrom="#2563eb" colorTo="#60a5fa" borderWidth={1.5} />
      )}
      <div className="flex items-center justify-between">
        <span className="text-xs sm:text-sm font-bold text-slate-700 uppercase tracking-wider">{label}</span>
        {icon && <div className="text-slate-500">{icon}</div>}
      </div>
      <div className="mt-3 flex items-baseline justify-between">
        <div className="text-2xl sm:text-3xl font-extrabold text-slate-900 tabular-nums tracking-tight">
          {value}
        </div>
        {badge}
      </div>
      {subtitle && (
        <div className="mt-2 text-xs sm:text-sm font-medium text-slate-600 flex items-center gap-1.5">
          {subtitle}
        </div>
      )}
    </div>
  );
};
