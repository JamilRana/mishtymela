"use client";

import React from "react";
import Link from "next/link";
import {
  TrendingUp,
  DollarSign,
  Receipt,
  Boxes,
  AlertTriangle,
  Store,
  ArrowUpRight,
  PlusCircle,
} from "lucide-react";
import { PageHeader } from "@/components/shared/PageHeader";
import { KpiCard } from "@/components/shared/KpiCard";
import { MoneyText } from "@/components/shared/MoneyText";
import { DateTimeText } from "@/components/shared/DateTimeText";
import { SalesTrendChart } from "@/components/dashboard/DashboardCharts";
import { useHydratedLanguage } from "@/stores/language";
import { toBnDigits } from "@/lib/bangla-numbers";

export interface DashboardViewProps {
  data: {
    kpis: {
      revenue: number;
      grossProfit: number;
      operatingExpenses: number;
      operatingProfit: number;
      stockValue: number;
      receivables: number;
      orders: number;
      cogs: number;
    };
    lowStock: Array<{
      id: string;
      name: string;
      sku: string;
      stockQty: number;
      reorderLevel: number;
    }>;
    salesByDay: Array<{
      day: string;
      revenue: number;
      orders: number;
    }>;
    topProducts: Array<{
      name: string;
      qty: number;
      revenue: number;
    }>;
    expensesByCategory: Array<{
      category: string;
      amount: number;
    }>;
    recentTransactions: Array<{
      id: string;
      type: "INCOME" | "EXPENSE";
      amount: number;
      accountName: string;
      categoryName: string;
      description: string;
      occurredAt: string;
    }>;
  };
}

export const DashboardView: React.FC<DashboardViewProps> = ({ data }) => {
  const { language } = useHydratedLanguage();
  const isBn = language === "bn";
  const { kpis, lowStock, salesByDay, topProducts, expensesByCategory, recentTransactions } = data;

  return (
    <div className="space-y-6">
      <PageHeader
        title="Store Dashboard"
        description="Real-time retail metrics, profit analytics, and stock health"
        actions={
          <div className="flex items-center gap-2">
            <Link
              href="/pos"
              className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-medium text-xs rounded-md shadow-xs transition-colors"
            >
              <Store className="w-4 h-4" />
              <span>{isBn ? "পিওএস টার্মিনাল খুলুন" : "Open POS Terminal"}</span>
            </Link>
          </div>
        }
      />

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        <KpiCard
          label={isBn ? "মোট বিক্রয় আয়" : "Total Revenue"}
          value={<MoneyText amount={kpis.revenue} />}
          subtitle={isBn ? `${toBnDigits(kpis.orders)} টি সফল অর্ডার` : `${kpis.orders} orders completed`}
          icon={<DollarSign className="w-4 h-4" />}
          withBeam={true}
        />
        <KpiCard
          label={isBn ? "মোট লাভ (Gross)" : "Gross Profit"}
          value={<MoneyText amount={kpis.grossProfit} />}
          subtitle={isBn ? `উপাদান খরচ: ৳${toBnDigits(kpis.cogs.toLocaleString())}` : `COGS: ৳${kpis.cogs.toLocaleString()}`}
          icon={<TrendingUp className="w-4 h-4" />}
        />
        <KpiCard
          label={isBn ? "পরিচালনা খরচ" : "Operating Expenses"}
          value={<MoneyText amount={kpis.operatingExpenses} />}
          subtitle={isBn ? "অন্যান্য ওভারহেড খরচ" : "Manual expenses"}
          icon={<Receipt className="w-4 h-4" />}
        />
        <KpiCard
          label={isBn ? "নিট অপারেটিং লাভ" : "Operating Profit"}
          value={<MoneyText amount={kpis.operatingProfit} />}
          subtitle={isBn ? "খরচ বাদ দিয়ে নিট লাভ" : "Net after overhead"}
          icon={<TrendingUp className="w-4 h-4" />}
        />
        <KpiCard
          label={isBn ? "মোট স্টক মূল্য" : "Stock Valuation"}
          value={<MoneyText amount={kpis.stockValue} />}
          subtitle={isBn ? "বর্তমান ইনভেন্টরি স্থিতি" : "Current inventory value"}
          icon={<Boxes className="w-4 h-4" />}
        />
        <KpiCard
          label={isBn ? "বাকি পাওনা (Due)" : "Receivables (Due)"}
          value={<MoneyText amount={kpis.receivables} negative={kpis.receivables > 0} />}
          subtitle={isBn ? "ক্রেডিট বাকির পরিমাণ" : "Outstanding credit"}
          icon={<AlertTriangle className="w-4 h-4" />}
        />
      </div>

      {/* Sales Trend Chart */}
      <div className="bg-white border border-slate-200 rounded-md p-5">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-sm font-semibold text-slate-900">
              {isBn ? "দৈনিক বিক্রয় ট্রেন্ড (বিগত ৩০ দিন)" : "Sales Trend (Last 30 Days)"}
            </h2>
            <p className="text-xs text-slate-500">
              {isBn ? "ঢাকা স্থানীয় সময় অনুযায়ী দৈনিক মোট বিক্রয়" : "Dhaka timezone daily revenue"}
            </p>
          </div>
          <span className="text-xs font-medium text-slate-500 bg-slate-100 px-2.5 py-1 rounded">
            ৳ BDT
          </span>
        </div>
        <SalesTrendChart data={salesByDay} />
      </div>

      {/* Two-Column Analytics: Top Products & Expenses */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Top Selling Products */}
        <div className="bg-white border border-slate-200 rounded-md p-5 flex flex-col justify-between">
          <div>
            <h2 className="text-sm font-semibold text-slate-900 mb-1">
              {isBn ? "সর্বোচ্চ বিক্রিত মিষ্টি ও পণ্য" : "Top Selling Products"}
            </h2>
            <p className="text-xs text-slate-500 mb-4">
              {isBn ? "আয়ের অবদান অনুযায়ী শীর্ষ পণ্যসমূহ" : "Ranked by revenue contribution"}
            </p>
            {topProducts.length === 0 ? (
              <p className="text-xs text-slate-400 py-8 text-center">
                {isBn ? "কোন বিক্রয় রেকর্ড পাওয়া যায়নি" : "No sales recorded yet"}
              </p>
            ) : (
              <div className="space-y-3">
                {topProducts.map((p, idx) => (
                  <div key={idx} className="flex items-center justify-between text-xs py-1 border-b border-slate-100 last:border-0">
                    <div className="flex items-center gap-2.5">
                      <span className="w-5 h-5 rounded-full bg-slate-100 text-slate-700 font-bold flex items-center justify-center text-xs">
                        {isBn ? toBnDigits(idx + 1) : idx + 1}
                      </span>
                      <span className="font-medium text-slate-800">{p.name}</span>
                    </div>
                    <div className="flex items-center gap-4 text-right">
                      <span className="text-slate-500">
                        {isBn ? `${toBnDigits(p.qty)} বিক্রিত` : `${p.qty} sold`}
                      </span>
                      <MoneyText amount={p.revenue} className="text-xs font-semibold" />
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
          <div className="pt-3 border-t border-slate-100 text-right">
            <Link href="/products" className="text-xs text-blue-600 hover:text-blue-700 font-medium inline-flex items-center gap-1">
              <span>{isBn ? "সকল পণ্য দেখুন" : "View all products"}</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </Link>
          </div>
        </div>

        {/* Operating Expenses Breakdown */}
        <div className="bg-white border border-slate-200 rounded-md p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-1">
              <h2 className="text-sm font-semibold text-slate-900">
                {isBn ? "খাতওয়ারি পরিচালনা খরচ" : "Expenses by Category"}
              </h2>
              <Link href="/finance" className="text-xs text-blue-600 hover:text-blue-700 font-medium">
                {isBn ? "+ খরচ লিখুন" : "Add Expense"}
              </Link>
            </div>
            <p className="text-xs text-slate-500 mb-4">
              {isBn ? "ম্যানুয়াল ওভারহেড ও দোকান পরিচালন ব্যয়" : "Manual overhead and operational costs"}
            </p>
            {expensesByCategory.length === 0 ? (
              <p className="text-xs text-slate-400 py-8 text-center">
                {isBn ? "কোন খরচের হিসাব নেই" : "No manual expenses logged"}
              </p>
            ) : (
              <div className="space-y-3">
                {expensesByCategory.map((e, idx) => (
                  <div key={idx} className="flex items-center justify-between text-xs py-1 border-b border-slate-100 last:border-0">
                    <span className="font-medium text-slate-800">{e.category}</span>
                    <MoneyText amount={e.amount} className="font-semibold text-rose-600" />
                  </div>
                ))}
              </div>
            )}
          </div>
          <div className="pt-3 border-t border-slate-100 text-right">
            <Link href="/finance" className="text-xs text-blue-600 hover:text-blue-700 font-medium inline-flex items-center gap-1">
              <span>{isBn ? "পূর্ণ হিসাব ও খতিয়ান" : "View Finance Ledger"}</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </Link>
          </div>
        </div>
      </div>

      {/* Two-Column Analytics: Recent Transactions & Low Stock Alerts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Transactions Table (2 cols) */}
        <div className="lg:col-span-2 bg-white border border-slate-200 rounded-md p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div>
                <h2 className="text-sm font-semibold text-slate-900">
                  {isBn ? "সাম্প্রতিক লেনদেন সমূহ" : "Recent Activity & Transactions"}
                </h2>
                <p className="text-xs text-slate-500">
                  {isBn ? "সর্বশেষ আর্থিক আয় ও খরচের তালিকা" : "Latest income and expense entries across accounts"}
                </p>
              </div>
              <Link href="/finance" className="text-xs text-blue-600 hover:text-blue-700 font-medium">
                {isBn ? "সকল লেনদেন" : "View all"}
              </Link>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-100 text-slate-500 uppercase text-xs tracking-wider font-semibold">
                    <th className="pb-2 font-semibold">{isBn ? "তারিখ" : "Date"}</th>
                    <th className="pb-2 font-semibold">{isBn ? "অ্যাকাউন্ট" : "Account"}</th>
                    <th className="pb-2 font-semibold">{isBn ? "ক্যাটেগরি" : "Category / Source"}</th>
                    <th className="pb-2 font-semibold">{isBn ? "বিবরণ" : "Description"}</th>
                    <th className="pb-2 font-semibold text-right">{isBn ? "পরিমাণ" : "Amount"}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {recentTransactions.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="py-6 text-center text-slate-400">
                        {isBn ? "কোন লেনদেন রেকর্ড করা হয়নি" : "No transactions recorded"}
                      </td>
                    </tr>
                  ) : (
                    recentTransactions.map((t) => (
                      <tr key={t.id} className="hover:bg-slate-50">
                        <td className="py-2.5">
                          <DateTimeText date={t.occurredAt} />
                        </td>
                        <td className="py-2.5 font-medium text-slate-800">{t.accountName}</td>
                        <td className="py-2.5">
                          <span className="text-xs text-slate-700 bg-slate-100 px-2 py-0.5 rounded font-medium">
                            {t.categoryName}
                          </span>
                        </td>
                        <td className="py-2.5 text-slate-600 truncate max-w-xs">{t.description}</td>
                        <td className="py-2.5 text-right font-medium">
                          <span className={t.type === "INCOME" ? "text-emerald-600" : "text-slate-800"}>
                            {t.type === "INCOME" ? "+" : "-"}
                            <MoneyText amount={t.amount} className="text-inherit" />
                          </span>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Low Stock Alerts (1 col) */}
        <div className="bg-white border border-slate-200 rounded-md p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-sm font-semibold text-slate-900 flex items-center gap-1.5">
                <AlertTriangle className="w-4 h-4 text-amber-500" />
                <span>{isBn ? "স্বল্প স্টক সতর্কতা" : "Low Stock Alerts"}</span>
              </h2>
              <p className="text-xs text-slate-500">
                {isBn ? "রি-অর্ডার সীমার নিচে থাকা পণ্যসমূহ" : "Products at or below reorder level"}
              </p>
            </div>
            <Link href="/inventory" className="text-xs text-blue-600 hover:text-blue-700 font-medium">
              {isBn ? "ম্যানেজ" : "Manage"}
            </Link>
          </div>
          {lowStock.length === 0 ? (
            <div className="py-8 text-center text-xs text-slate-400">
              {isBn ? "সকল পণ্যের স্টক সন্তোষজনক" : "All product stock levels healthy"}
            </div>
          ) : (
            <div className="space-y-3">
              {lowStock.map((p) => (
                <div key={p.id} className="flex items-center justify-between text-xs py-2 border-b border-slate-100 last:border-0">
                  <div>
                    <span className="font-semibold text-slate-900 block">{p.name}</span>
                    <span className="text-xs text-slate-500 font-mono">SKU: {p.sku}</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="text-right">
                      <span className="text-amber-600 font-semibold block">
                        {isBn ? `${toBnDigits(p.stockQty)} বাকি` : `${p.stockQty} left`}
                      </span>
                      <span className="text-xs text-slate-400">
                        {isBn ? `সতর্কতা: ${toBnDigits(p.reorderLevel)}` : `Reorder at ${p.reorderLevel}`}
                      </span>
                    </div>
                    <Link
                      href={`/inventory?restock=${p.id}`}
                      className="p-1.5 bg-blue-50 text-blue-600 hover:bg-blue-100 rounded transition-colors"
                      title={isBn ? "পুনরায় স্টক ইন করুন" : "Restock this product"}
                    >
                      <PlusCircle className="w-4 h-4" />
                    </Link>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
